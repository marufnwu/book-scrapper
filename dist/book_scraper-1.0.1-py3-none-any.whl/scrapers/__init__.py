from .scraper import ScrapedItem
from .generic import Generic 