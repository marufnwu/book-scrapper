from scrapers.scraper import BaseScraper


class Generic(BaseScraper):
    def f():
        return 0